<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\TableBook;
use App\Models\ProductOrder;
use App\Models\SubOrder;



class DashboardController extends Controller
{
    public function dashboard(Request $request) {
      $data['table_books'] = TableBook::orderby('id','desc')->take(10)->get();
      $data['orders'] = ProductOrder::orderby('id','desc')->take(10)->get();

      $search = $request->search;
      $type = $request->orders_from;
      $servingMethod = $request->serving_method;
      $orderStatus = $request->order_status;
      $paymentStatus = $request->payment_status;
      $completed = $request->completed;
      $orderDate = $request->order_date;
      $deliveryDate = $request->delivery_date;

      $state = $request->state != null ? intVal($request->state)  : 0;
      $type = $request->type != null ? intVal($request->type)  : 1;


      if($state == 2){
          $data['sub_orders'] = SubOrder::with('order','products.item.product')
          ->where('sub_orders.state', $state)
          ->orderBy('id', 'DESC')->paginate(12);
      }else{
          $data['sub_orders'] = SubOrder::with('order','products.item.product')
          ->where('sub_orders.state', $state)
          ->where('sub_orders.type', $type)
          ->orderBy('id', 'DESC')->paginate(12);
      }

       $data['state'] = $state."";
       $data['type'] = $type."";
       $data['sub_orders_count'] = 0;


      return view('admin.dashboard',$data);
    }
}
