<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<title>{{$bs->website_title}}</title>
	<link rel="icon" href="{{asset('assets/front/img/'.$bs->favicon)}}">
	@includeif('admin.partials.styles')
    @php
        $selLang = App\Models\Language::where('code', request()->input('language'))->first();
    @endphp
    @if (!empty($selLang) && $selLang->rtl == 1)
    <style>
    #editModal form input,
    #editModal form textarea,
    #editModal form select {
        direction: rtl;
    }
    #editModal form .note-editor.note-frame .note-editing-area .note-editable {
        direction: rtl;
        text-align: right;
    }

    </style>
    @endif
<style>
        .alert-success{
        transform: scale(2.5);
    } 
    .card-round {
    border-radius: 30px;
    }
    a,button{
            border-radius: 15px !important;
            margin-left:5px !important;
    }
    .form-control:disabled, .form-control[readonly] {
    min-width: 70px;
}
    .logo-header .logo .navbar-brand {
    max-height: 60px;
}
</style>
</head>
<body data-background-color="dark">
	<div class="wrapper @yield('sidebar')">

    {{-- top navbar area start --}}
    @includeif('admin.partials.top-navbar')
    {{-- top navbar area end --}}


    {{-- side navbar area start --}}
    @includeif('admin.partials.side-navbar')
    {{-- side navbar area end --}}


		<div class="main-panel">
        <div class="content">
            <div class="page-inner">
            @yield('content')
            </div>
        </div>
            @includeif('admin.partials.footer')
		</div>

	</div>

	@includeif('admin.partials.scripts')

    {{-- Loader --}}
    <div class="request-loader">
        <img src="{{asset('assets/admin/img/loader.gif')}}" alt="">
    </div>
    {{-- Loader --}}
    <script>
    var bgcolor = document.querySelectorAll('*[data-background-color= "dark"]');
    var bgcolor2 = document.querySelectorAll('*[data-background-color= "dark2"]');
    var textCol = document.querySelectorAll('.text-white');
    if (sessionStorage.getItem('theme') == null) {
        sessionStorage.setItem('theme', 'dark');
    }
    function switchTheme () {
        textCol.forEach(element => {
                if (sessionStorage.getItem('theme') === 'dark') {
                    element.classList.replace('text-white', 'text-black');
                }
                else {
                    element.classList.replace('text-black', 'text-white');
                }
            })
            bgcolor.forEach(element => {
                if(sessionStorage.getItem('theme') === 'dark') {
                    element.setAttribute('data-background-color', 'white');
                }
                else {
                    element.setAttribute('data-background-color', 'dark');
                }
            });
            bgcolor2.forEach(element => {
                if(sessionStorage.getItem('theme') === 'dark') {
                    element.setAttribute('data-background-color', 'white');
                }
                else {
                    element.setAttribute('data-background-color', 'dark2');
                }
            });
    }
    switchTheme();
        document.querySelector('.switch input[type=checkbox]').addEventListener('change', function () {
            if (sessionStorage.getItem('theme') === 'dark') {
                sessionStorage.setItem('theme', 'white');
            }
            else {
                sessionStorage.setItem('theme', 'dark');
            }
            switchTheme();
        })
    </script>
    <script>
    $('.timepicker').timepicker({
            timeFormat: 'HH:mm',
        });
    </script>
    <script>

    $(function ($) {
    "use strict";
        // Realtime Order Notification
    // Enable pusher logging - don't include this in production
    Pusher.logToConsole = false;

    var pusher = new Pusher(pusherAppKey, {
        cluster: pusherCluster
    });

    var channel = pusher.subscribe('order-placed-channel');
    channel.bind('order-placed-event', function (data) {
        if ($("#refreshOrder").length > 0) {
            $(".request-loader").addClass("show");
            $("#refreshOrder").load(location.href + " #refreshOrder", function () {
                $(".request-loader").removeClass("show");
            });
        }

        audio.play();

        // show notification
        var content = {};

        content.message = "{{__('New Order Received!')}}";
        content.title = "{{__('Success')}}";
        content.icon = 'fa fa-bell';
        

            $.notify(content, {
            type: 'success',
            placement: {
                from: 'top',
                align: 'center'
            },
            offset: {
                y: '100',
            },
            animate: {
            	enter: 'animated fadeInDown',
            	exit: 'animated fadeOutUp'
            },
            delay: 0
        });
    });


    var waiterCallChannel = pusher.subscribe('waiter-called-channel');
    waiterCallChannel.bind('waiter-called-event', function (data) {
        waiterCallAudio.play();

        // show notification
        var content = {};

        content.message = '<strong class="text-danger">{{__("Table")}} - ' + data.table + '</strong> {{__("ask for waiter!")}}';
        content.title = "{{__('Need a waiter!')}}";
        content.icon = 'fa fa-bell';

        $.notify(content, {
            type: 'secondary',
            placement: {
                from: 'top',
                align: 'right'
            },
            delay: 0,
        });
    });
    
    });
    </script>
</body>
</html>
