@extends('admin.layout')

@section('content')
  <div class="page-header">
    <h4 class="page-title">{{__('Edit')}}: {{__('Email Template')}}</h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="{{route('admin.dashboard')}}">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#">{{__('Settings')}}</a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#">{{__('Email Settings')}}</a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#">{{__('Edit')}}: {{__('Email Template')}}</a>
      </li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="card-title d-inline-block">{{__('Edit')}}: {{__('Email Template')}}</div>
          <a class="btn btn-info btn-sm float-right d-inline-block" href="{{route('admin.email.templates')}}">
            <span class="btn-label">
              <i class="fas fa-backward"></i>
            </span>
            {{__('back')}}
          </a>
        </div>
        <div class="card-body pt-5 pb-5">
          <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <table class="table table-striped mb-5" style="border: 1px solid #0000005a;">
                    <thead>
                      <tr>
                        <th class="text-white" scope="col">BB {{__('code')}}</th>
                        <th class="text-white" scope="col">{{__('Meaning')}}</th>
                      </tr>
                    </thead>
                    <tbody>
                        <tr>
                          <td>
                            {customer_name}
                          </td>
                          <th scope="row">
                            {{__('Customer Name')}}
                          </th>
                        </tr>

                        @if ($template->email_type == 'email_verification')
                        <tr>
                            <td>
                              {verification_link}
                            </td>
                            <th scope="row">
                              {{__('Verification Link')}}
                            </th>
                        </tr>
                        @endif

                        @if ($template->email_type == 'order_received' || $template->email_type == 'order_preparing' || $template->email_type == 'order_ready_to_pick_up' || $template->email_type == 'order_picked_up' || $template->email_type == 'order_delivered' || $template->email_type == 'order_cancelled' || $template->email_type == 'food_checkout')

                        <tr>
                          <td>
                            {order_number}
                          </td>
                          <th scope="row">
                            {{__('Order Number')}}
                          </th>
                        </tr>
                        <tr>
                          <td>
                            {order_link}
                          </td>
                          <th scope="row">
                            {{__('Order Link')}}
                          </th>
                        </tr>

                        @endif
                        <tr>
                          <td>
                            {website_title}
                          </td>
                          <th scope="row">
                            {{__('Website Title')}}
                          </th>
                        </tr>
                    </tbody>
                </table>

              <form id="ajaxForm" action="{{route('admin.email.templateUpdate', $template->id)}}" method="post" enctype="multipart/form-data">
                @csrf

                @php
                    if ($template->email_type == 'order_pickedup_pick_up') {
                        $etype = "Order Picked up (For 'Pick up')";
                    } elseif ($template->email_type == 'order_pickedup') {
                        $etype = "Order Picked up (For 'Home Delivery')";
                    } elseif ($template->email_type == 'order_ready_to_pickup_pick_up') {
                        $etype = "Order Ready to Pick up (For 'Pick up')";
                    } elseif ($template->email_type == 'order_ready_to_pickup') {
                        $etype = "Order Ready to Pick up (For 'Home Delivery')";
                    } else {
                        $etype = str_replace("_", " ", $template->email_type);
                    }
                @endphp

                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                           <label for="">Email Type **</label>
                           <input type="text" class="form-control" name="email_type" placeholder="Email Type" value="{{$etype}}" readonly>
                           <p id="erremail_type" class="mb-0 text-danger em"></p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="form-group">
                           <label for="">{{__('Email Subject')}} **</label>
                           <input type="text" class="form-control" name="email_subject"  placeholder="{{__('Email Subject')}}..." value="{{$template->email_subject}}">
                           <p id="erremail_subject" class="mb-0 text-danger em"></p>
                        </div>
                    </div>
                </div>

                <div class="row">
                   <div class="col-lg-12">
                      <div class="form-group">
                         <label for="">{{__('Email Body')}} **</label>
                         <textarea class="form-control summernote" name="email_body" placeholder="{{__('Email Body')}}..." data-height="300">{{$template->email_body}}</textarea>
                         <p id="erremail_body" class="mb-0 text-danger em"></p>
                      </div>
                   </div>
                </div>

             </form>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <div class="form">
            <div class="form-group from-show-notify row">
              <div class="col-12 text-center">
                <button type="submit" id="submitBtn" class="btn btn-success">{{__('Update')}}</button>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>

@endsection
