<footer class="footer">
  <div class="container-fluid">
    <div class="d-block mx-auto">
        Copyright © <?php echo date("Y"); ?> | ClicknFood
    </div>
  </div>
</footer>
